fetch('assets/data/dancers.json')
  .then(response => response.json())
  .then(data => {
    const container = document.getElementById('dancersContainer');
    data.forEach(dancer => {
      const card = document.createElement('div');
      card.className = 'dancer-card';
      card.innerHTML = `
        <img src="${dancer.image}" alt="${dancer.name}" class="dancer-image">
        <div class="dancer-info">
          <div class="dancer-name">${dancer.name}</div>
          <div class="dancer-specialty">${dancer.specialty}</div>
          <div class="dancer-experience">Experience: ${dancer.experience}</div>
          <div class="dancer-bio">${dancer.bio}</div>
        </div>
      `;
      container.appendChild(card);
    });
  })
  .catch(error => console.error('Error loading dancers:', error));