<?php

// Users data
$imSettings['access']['webregistrations_gid'] = 'ht9f8h69';
$imSettings['access']['users'] = array(
	'admin' => array(
		'groups' => array('9xz1030z'),
		'id' => '9xz1030z',
		'name' => 'Admin',
		'password' => 'p5eaef75',
		'email' => '',
		'page' => 'index.html'
	),
	'newuser' => array(
		'groups' => array('6iz29739'),
		'id' => '6iz29739',
		'name' => 'NewUser',
		'password' => 'nt064dqt',
		'email' => '',
		'page' => 'index.html'
	)
);

// Admins list
$imSettings['access']['admins'] = array('9xz1030z');

// Page/Users permissions
$imSettings['access']['pages'] = array();

// End of file access.inc.php