<?php
	$oNameList = array("dkm","fje","7lk","vsl","4w3","jkv","cp5","zha","hrh","n5s");
	$oCharList = array("L","C","U","V","3","X","L","7","4","T");
// End of file imkeys.php